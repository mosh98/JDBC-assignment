UPDATE superhero 
SET hero_name = 'Luzkin' 
WHERE hero_id = 3;