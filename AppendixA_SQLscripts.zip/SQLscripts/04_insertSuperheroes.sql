INSERT INTO superhero (hero_name, hero_alias, hero_origin) VALUES ('Superman', 'Hacker', 'Mosleh');
INSERT INTO superhero (hero_name, hero_alias, hero_origin) VALUES ('Wonder Woman', 'Hacker', 'Zakhida');
INSERT INTO superhero (hero_name, hero_alias, hero_origin) VALUES ( 'Nightcrawler', 'Hacker', 'Erik');