CREATE TABLE superhero_power (
    superheroId int REFERENCES superhero(hero_id),
    powerId int REFERENCES power(power_id),
    PRIMARY KEY (superheroId, powerId)
);