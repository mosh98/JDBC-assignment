CREATE TABLE superhero (
  hero_id SERIAL PRIMARY KEY ,
  hero_name VARCHAR(255) NOT NULL,
  hero_alias VARCHAR(255) NOT NULL,
  hero_origin VARCHAR(255) NOT NULL
);

CREATE TABLE assistant (
	assistant_id SERIAL PRIMARY KEY,
	assistant_name VARCHAR(255) UNIQUE NOT NULL
);

CREATE TABLE power (
	power_id SERIAL PRIMARY KEY,
	power_name VARCHAR(255) NOT NULL,
	power_description TEXT
);