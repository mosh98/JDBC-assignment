-- 00_createDatabase.sql

DROP DATABASE IF EXISTS SuperherosDb;
CREATE DATABASE SuperherosDb;

-- 01_tableCreate.sql

DROP TABLE IF EXISTS superhero CASCADE;
DROP TABLE IF EXISTS assistant CASCADE;
DROP TABLE IF EXISTS power CASCADE;
DROP TABLE IF EXISTS superhero_power CASCADE;

CREATE TABLE superhero (
  hero_id SERIAL PRIMARY KEY ,
  hero_name VARCHAR(255) NOT NULL,
  hero_alias VARCHAR(255) NOT NULL,
  hero_origin VARCHAR(255) NOT NULL
);

CREATE TABLE assistant (
	assistant_id SERIAL PRIMARY KEY,
	assistant_name VARCHAR(255) UNIQUE NOT NULL
);

CREATE TABLE power (
	power_id SERIAL PRIMARY KEY,
	power_name VARCHAR(255) NOT NULL,
	power_description TEXT
);

-- 02_relationshipSuperheroAssistant.sql

ALTER TABLE assistant
DROP COLUMN IF EXISTS superheroid;

ALTER TABLE assistant
ADD COLUMN superheroId INT UNIQUE REFERENCES superhero(hero_id);

-- 03_relationshipSuperheroPower.sql

CREATE TABLE superhero_power (
    superheroId int REFERENCES superhero(hero_id),
    powerId int REFERENCES power(power_id),
    PRIMARY KEY (superheroId, powerId)
);

-- 04_insertSuperheroes.sql

INSERT INTO superhero (hero_name, hero_alias, hero_origin) VALUES ('Superman', 'Hacker', 'Mosleh');
INSERT INTO superhero (hero_name, hero_alias, hero_origin) VALUES ('Wonder Woman', 'Hacker', 'Zakhida');
INSERT INTO superhero (hero_name, hero_alias, hero_origin) VALUES ( 'Nightcrawler', 'Hacker', 'Erik');

-- 05_insertAssistants.sql

INSERT INTO assistant (assistant_name, superheroId) VALUES ('Arif', 1);
INSERT INTO assistant (assistant_name, superheroId) VALUES ('Lovisa', 2);
INSERT INTO assistant (assistant_name, superheroId) VALUES ('Jacob', 3);

-- 06_powers.sql

INSERT INTO Power (power_name, power_description) VALUES ('Super Strength', 'Hypersonic blast');
INSERT INTO Power (power_name, power_description) VALUES ('Flight', 'Can fly');
INSERT INTO Power (power_name, power_description) VALUES ('Teleportation', 'Can teleport');
INSERT INTO Power (power_name, power_description) VALUES ('Invisibility', 'You can not see me');

INSERT INTO superhero_power (superheroId, powerId) VALUES (1, 1); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (1, 2); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (2, 2); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (3, 3); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (2, 4); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (1, 4);

-- 07_updateSuperhero.sql

UPDATE superhero 
SET hero_name = 'Luzkin' 
WHERE hero_id = 3;

-- 08_deleteAssistant.sql

DELETE FROM assistant WHERE assistant_name = 'Melvin';

--  a superhero cannot be deleted if it is used in the assistant table
DELETE FROM superhero WHERE hero_name = 'Wonder Woman';
