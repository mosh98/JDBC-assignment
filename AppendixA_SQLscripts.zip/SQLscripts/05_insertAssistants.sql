INSERT INTO assistant (assistant_name, superheroId) VALUES ('Arif', 1);
INSERT INTO assistant (assistant_name, superheroId) VALUES ('Lovisa', 2);
INSERT INTO assistant (assistant_name, superheroId) VALUES ('Jacob', 3);