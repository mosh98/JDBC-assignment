DELETE FROM assistant WHERE assistant_name = 'Melvin';

--  a superhero cannot be deleted if it is used in the assistant table
DELETE FROM superhero WHERE hero_name = 'Wonder Woman';