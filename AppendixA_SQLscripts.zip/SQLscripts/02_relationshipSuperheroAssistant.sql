ALTER TABLE assistant
ADD COLUMN superheroId INT UNIQUE REFERENCES superhero(hero_id);