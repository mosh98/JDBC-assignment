INSERT INTO Power (power_name, power_description) VALUES ('Super Strength', 'Hypersonic blast');
INSERT INTO Power (power_name, power_description) VALUES ('Flight', 'Can fly');
INSERT INTO Power (power_name, power_description) VALUES ('Teleportation', 'Can teleport');
INSERT INTO Power (power_name, power_description) VALUES ('Invisibility', 'You can not see me');

INSERT INTO superhero_power (superheroId, powerId) VALUES (1, 1); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (1, 2); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (2, 2); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (3, 3); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (2, 4); 
INSERT INTO superhero_power (superheroId, powerId) VALUES (1, 4);